<br><br><br>


<form method="post" action="" enctype="multipart/form-data">

	<input type="file" name="avatar" id="">
	
	<input type="submit" value="Send" name="Send">
</form>