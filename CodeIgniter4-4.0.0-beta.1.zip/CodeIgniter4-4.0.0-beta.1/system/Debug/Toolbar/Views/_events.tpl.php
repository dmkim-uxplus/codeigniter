<table>
    <thead>
        <tr>
            <th class="debug-bar-width6r">Time</th>
            <th>Event Name</th>
            <th>Times Called</th>
        </tr>
    </thead>
    <tbody>
    {events}
        <tr>
            <td class="narrow">{ duration } ms</td>
            <td>{event}</td>
            <td>{count}</td>
        </tr>
    {/events}
    </tbody>
</table>
