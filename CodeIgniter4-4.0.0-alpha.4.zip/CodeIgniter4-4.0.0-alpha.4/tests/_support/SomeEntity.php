<?php

namespace Tests\Support;

use CodeIgniter\Entity;

class SomeEntity extends Entity
{

	protected $foo = null;
	protected $bar;

}
