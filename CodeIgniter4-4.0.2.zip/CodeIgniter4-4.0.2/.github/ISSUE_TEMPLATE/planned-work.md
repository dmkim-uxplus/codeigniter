---
name: Planned work
about: Approved work planning
title: 'Dev: '
labels: dev
assignees: ''

---

Repo maintainers will create "issues" for planned work, so it can be tracked.
