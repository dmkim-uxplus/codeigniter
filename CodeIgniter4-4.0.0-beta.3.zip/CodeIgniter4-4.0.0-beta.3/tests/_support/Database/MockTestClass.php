<?php

namespace Tests\Support\Database;

class MockTestClass
{
}