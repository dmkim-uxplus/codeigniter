---
name: Feature request
about: How to submit a feature request
title: ''
labels: ''
assignees: ''

---

Please submit feature requests to our [forum](https://forum.codeigniter.com/forum-29.html).
We use github issues to track bugs and planned work.
